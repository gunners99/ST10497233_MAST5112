export const sampleCourses = ['Starter', 'Main', 'Dessert'] as const;
export type SampleCourse = typeof sampleCourses[number];
