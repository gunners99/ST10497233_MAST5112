import React, { createContext, useState, ReactNode } from 'react';
import { sampleCourses } from '../utils/constants';
import { MenuItem, Course } from '../types';

const makeId = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);

interface MenuContextValue {
  menuItems: MenuItem[];
  addItem: (item: Omit<MenuItem, 'id'>) => void;
  removeItem: (id: string) => void;
  courses: readonly Course[];
}

export const MenuContext = createContext<MenuContextValue | undefined>(undefined);

const predefined: MenuItem[] = [
  { id: makeId(), name: 'Tomato Basil Soup', description: 'Creamy tomato soup infused with fresh basil and served with a slice of toasted sourdough.', course: 'Starter', price: 45.0 },
  { id: makeId(), name: 'Crispy Calamari', description: 'Lightly battered calamari rings served with a tangy lemon aioli.', course: 'Starter', price: 65.0 },
  { id: makeId(), name: 'Garden Salad', description: 'A mix of crisp lettuce, cherry tomatoes, cucumbers, and feta with a balsamic dressing.', course: 'Starter', price: 40.0 },
  { id: makeId(), name: 'Grilled Chicken Alfredo', description: 'Tender grilled chicken breast served over fettuccine pasta in a creamy Alfredo sauce.', course: 'Main', price: 120.0 },
  { id: makeId(), name: 'Beef Burger Deluxe', description: '200g beef patty with cheddar cheese, caramelized onions, lettuce, tomato, and house sauce.', course: 'Main', price: 95.0 },
  { id: makeId(), name: 'Vegetable Stir-Fry', description: 'Seasonal vegetables sautéed in a soy-ginger glaze, served with jasmine rice.', course: 'Main', price: 85.0 },
  { id: makeId(), name: 'Chocolate Lava Cake', description: 'Warm chocolate cake with a gooey molten center, served with vanilla ice cream.', course: 'Dessert', price: 55.0 },
  { id: makeId(), name: 'Cheesecake Slice', description: 'Creamy New York–style cheesecake topped with fresh berries.', course: 'Dessert', price: 60.0 },
  { id: makeId(), name: 'Ice Cream Trio', description: 'A scoop each of chocolate, vanilla, and strawberry ice cream topped with chocolate sauce.', course: 'Dessert', price: 40.0 }
];

export const MenuProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>(predefined);

  const addItem = (item: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = { id: makeId(), ...item };
    setMenuItems(prev => [newItem, ...prev]);
  };

  const removeItem = (id: string) => {
    setMenuItems(prev => prev.filter(i => i.id !== id));
  };

  return (
    <MenuContext.Provider value={{ menuItems, addItem, removeItem, courses: sampleCourses }}>
      {children}
    </MenuContext.Provider>
  );
};
