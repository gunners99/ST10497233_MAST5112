import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { MenuContext } from '../context/MenuContext';
import MenuItemCard from '../components/MenuItemCard';
import { Course, MenuItem } from '../types';

const FilterScreen: React.FC = () => {
  const ctx = useContext(MenuContext);
  if (!ctx) return null;
  const { menuItems, removeItem, courses } = ctx;
  const [selected, setSelected] = useState<Course | null>(null);

  const filtered = selected ? menuItems.filter((m: MenuItem) => m.course === selected) : menuItems;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Filter by course</Text>
      <View style={styles.row}>
        <TouchableOpacity
          onPress={() => setSelected(null)}
          style={[styles.filterBtn, selected === null && styles.filterBtnActive]}
        >
          <Text>All</Text>
        </TouchableOpacity>
        {courses.map((c) => (
          <TouchableOpacity
            key={c}
            onPress={() => setSelected(c)}
            style={[styles.filterBtn, selected === c && styles.filterBtnActive]}
          >
            <Text>{c}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={{ marginTop: 12 }}>Showing {filtered.length} items</Text>

      <FlatList
        data={filtered}
        keyExtractor={(i: MenuItem) => i.id}
        renderItem={({ item }: { item: MenuItem }) => <MenuItemCard item={item} onDelete={removeItem} />}
        contentContainerStyle={{ paddingVertical: 8 }}
      />
    </View>
  );
};

export default FilterScreen;

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f6f7fb' },
  title: { fontSize: 18, fontWeight: '700' },
  row: { flexDirection: 'row', marginTop: 12 },
  filterBtn: { backgroundColor: '#fff', padding: 10, borderRadius: 8, marginRight: 8 },
  filterBtnActive: { backgroundColor: '#ddd' },
});
