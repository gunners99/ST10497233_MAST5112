import React, { useContext } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { MenuContext } from '../context/MenuContext';
import MenuItemCard from '../components/MenuItemCard';
import { MenuItem } from '../types';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: undefined;
  Filter: undefined;
  AddItem: undefined;
};

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'Home'>;
};

const HomeScreen: React.FC<Props> = ({ navigation }) => {
  const ctx = useContext(MenuContext);
  if (!ctx) return null;
  const { menuItems, removeItem } = ctx;

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Complete Menu</Text>
        <View style={styles.actionsRow}>
          <TouchableOpacity onPress={() => navigation.navigate('Filter')} style={styles.actionBtn}>
            <Text>Filter</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('AddItem')} style={styles.primaryBtn}>
            <Text style={{ color: '#fff' }}>Add Item</Text>
          </TouchableOpacity>
        </View>
      </View>

      <Text style={styles.countText}>Total items: {menuItems.length}</Text>

      {menuItems.length === 0 ? (
        <View style={styles.emptyBox}>
          <Text style={{ color: '#666' }}>No menu items yet — add one using "Add Item"</Text>
        </View>
      ) : (
        <FlatList
          data={menuItems}
          keyExtractor={(item: MenuItem) => item.id}
          renderItem={({ item }: { item: MenuItem }) => <MenuItemCard item={item} onDelete={removeItem} />}
          contentContainerStyle={{ paddingVertical: 8 }}
        />
      )}
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f6f7fb' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: '700' },
  actionsRow: { flexDirection: 'row', alignItems: 'center' },
  actionBtn: { marginRight: 10, padding: 8, borderRadius: 8, backgroundColor: '#fff' },
  primaryBtn: { padding: 10, backgroundColor: '#111', borderRadius: 8 },
  countText: { marginTop: 12, color: '#444' },
  emptyBox: { marginTop: 24, padding: 20, borderRadius: 12, backgroundColor: '#fff', alignItems: 'center' },
});
