import React, { useState, useContext } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { MenuContext } from '../context/MenuContext';
import { Picker } from '@react-native-picker/picker';
import { Course } from '../types';

import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: undefined;
  Filter: undefined;
  AddItem: undefined;
};

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'AddItem'>;
};

const AddItemScreen: React.FC<Props> = ({ navigation }) => {
  const ctx = useContext(MenuContext);
  if (!ctx) return null;
  const { addItem, courses } = ctx;

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState<Course>(courses[0]);
  const [price, setPrice] = useState('');

  function onSave() {
    if (!name.trim() || !price.trim()) {
      Alert.alert('Validation', 'Please enter the dish name and price.');
      return;
    }

    addItem({ name: name.trim(), description: description.trim(), course, price: Number(price) });
    // clear
    setName('');
    setDescription('');
    setPrice('');
    setCourse(courses[0]);
    navigation.goBack();
  }

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Dish name</Text>
      <TextInput value={name} onChangeText={setName} style={styles.input} placeholder="e.g. Grilled Salmon" />

      <Text style={styles.label}>Description</Text>
      <TextInput
        value={description}
        onChangeText={setDescription}
        style={[styles.input, { height: 80 }]}
        multiline
        placeholder="Short description (optional)"
      />

      <Text style={styles.label}>Course</Text>
      <View style={styles.pickerWrap}>
        <Picker selectedValue={course} onValueChange={(value: Course) => setCourse(value)}>
          {courses.map((c) => (
            <Picker.Item key={c} label={c} value={c} />
          ))}
        </Picker>
      </View>

      <Text style={styles.label}>Price (ZAR)</Text>
      <TextInput
        keyboardType="numeric"
        value={price}
        onChangeText={setPrice}
        style={styles.input}
        placeholder="e.g. 120.50"
      />

      <TouchableOpacity style={styles.saveBtn} onPress={onSave}>
        <Text style={{ color: '#fff', fontWeight: '700' }}>Save</Text>
      </TouchableOpacity>
    </View>
  );
};

export default AddItemScreen;

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f6f7fb' },
  label: { marginTop: 12, marginBottom: 6, color: '#333', fontWeight: '600' },
  input: { backgroundColor: '#fff', borderRadius: 10, padding: 12, fontSize: 15 },
  pickerWrap: { backgroundColor: '#fff', borderRadius: 10, overflow: 'hidden' },
  saveBtn: { marginTop: 20, padding: 14, borderRadius: 12, alignItems: 'center', backgroundColor: '#111' },
});
