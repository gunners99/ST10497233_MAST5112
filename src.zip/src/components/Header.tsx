import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

interface HeaderProps { title: string; }

export default function Header({ title }: HeaderProps) {
  return (
    <View style={styles.container}>
      <Image source={require('../assets/restaurant.png')} style={styles.image} />
      <Text style={styles.title}>{title}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { width:'100%', alignItems:'center', paddingTop:40, paddingBottom:12, backgroundColor:'#fff', borderBottomWidth:1, borderBottomColor:'#e0e0e0' },
  image: { width:80, height:80, borderRadius:12, marginBottom:8 },
  title: { fontSize:22, fontWeight:'700', color:'#1a237e' }
});
