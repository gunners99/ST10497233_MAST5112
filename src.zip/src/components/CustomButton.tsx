import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';

interface Props { title: string; onPress: () => void; style?: ViewStyle; textStyle?: TextStyle; color?: string; }

export default function CustomButton({ title, onPress, style, textStyle, color='#1a237e' }: Props) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.button, {backgroundColor: color}, style]}>
      <Text style={[styles.text, textStyle]}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: { padding:14, borderRadius:12, alignItems:'center', marginVertical:6 },
  text: { color:'#fff', fontWeight:'700', fontSize:16 }
});
